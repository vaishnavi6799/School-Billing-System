<?php
session_start();
require'dbconfi/config.php';
echo $_GET['id'];
echo $_GET['fullname'];
echo $_GET['gender'];
$_GET['fathername'];
$_GET['mothername'];
$_GET['DateofBirth'];
$_GET['class'];
$_GET['RollNo'];
$_GET['PersonalAddress'];
$_GET['EmailId'];
$_GET['MobileNo'];
$_GET['guardianNo'];
?>
<!DOCTYPE html>
<html>
<head >
<title>Student profile</title>

<link rel="stylesheet" href="css/style.css">
</head>

<body style="background:url(https://previews.123rf.com/images/tatus/tatus1407/tatus140700020/29843115-back-to-school-background.jpg); background-size:100%;">

  <center><h2 style="font-size:50px;color:Black;font-family:Heebo;">PROFILE</h2>
  <img src="imgs/avatar.jpg" class="avatar"/>
  </center>
  
  <form class="myform" action="studentprofile.php" method="post">
   <label><b>Full name:</b></label><br>
   <input name="fullname" type="text" class="inputvalues" readonly="readonly" value="<?php echo $_GET['fullname']?>" required/><br>
    <label><b>Gender:</b></label>
<input name="gender" type="text" class="inputvalues" readonly="readonly" value="<?php echo $_GET['gender']?>" required/><br>
    
        <label><b>Father's name:</b></label><br>
   <input name="fathername" type="text" class="inputvalues" readonly="readonly" value="<?php echo $_GET['fathername']?>" required/><br>
         <label><b>Mother's name:</b></label><br>
   <input name="mothername" type="text" class="inputvalues" readonly="readonly" value="<?php echo $_GET['mothername']?>" required/><br>
     <label><b>Date of Birth:</b></label><br>
   <input name="DateofBirth" type="text" class="inputvalues" readonly="readonly"  value="<?php echo $_GET['DateofBirth']?>" required/><br>
       
      <label><b>class:</b></label>
      <input class="class" name="class" readonly="readonly"  value="<?php echo $_GET['class']?>">
      
      
      <br>
     <label><b>Roll No:</b></label><br>
   <input name="RollNo" type="text" class="inputvalues" readonly="readonly" value="<?php echo $_GET['RollNo']?>" required/><br>
   <label><b>Personal Address:</b></label><br>
   <input name="PersonalAddress" type="text" class="inputvalues" readonly="readonly"  value="<?php echo $_GET['PersonalAddress']?>" required/><br>
   <label><b>Email Id:</label><br>
   <input name="EmailId" type="text" class="inputvalues" readonly="readonly"  value="<?php echo $_GET['EmailId']?>" required/><br>
    <label><b>Parent ph.No:</b></label><br>
   <input name="MobileNo" type="text" class="inputvalues" readonly="readonly"  value="<?php echo $_GET['MobileNo']?>" required/><br>
    <label><b>Guardian ph.No:</b></label><br>
   <input name="guardianNo" type="text" class="inputvalues" readonly="readonly" value="<?php echo $_GET['guardianNo']?>" required/><br>
    
  
   <a href="subject.php"><input name="submit" type="button" id="SignUp_btn" value="View marks"/><br>
   <a href="fstudent.php"><input type="button" id="Back_btn" value="<<Back to Student"/><br></a>
   
  </form>
 <?php
 
 ?>

</body>
</html>














