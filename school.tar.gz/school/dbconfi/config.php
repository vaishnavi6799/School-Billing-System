<?php
$con=mysqli_connect("localhost","root","kutti6799")or die("Unable to connect");
mysqli_select_db($con,'sampleLoginDB');
?>
