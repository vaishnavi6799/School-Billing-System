<?php

require'dbconfi/config.php';
?>
<!DOCTYPE html>
<html>
<head >
<title>update record</title>

<link rel="stylesheet" href="css/style.css">
</head>

<body style="background:url(https://previews.123rf.com/images/tatus/tatus1407/tatus140700020/29843115-back-to-school-background.jpg); background-size:100%;">

  <center><h2 style="font-size:50px;color:Black;font-family:Heebo;">UPLOAD FILES</h2>
  <img src="imgs/avatar.jpg" class="avatar"/>
  </center>
  
  <form class="myform" action="updatemarks.php" method="post" enctype="multipart/form-data">
   <input name="file" type="file" id="SignUp_btn" /><br>
   <button name="submit" type="submit" id="SignUp_btn">Upload</button><br>
  <a href="findex.php"> <input type="button" id="Back_btn" value="<<Back to Homepage"/><br></a>
 
  </form>
<?php
  if(isset($_POST['submit'])){
  $file=$_FILES['file'];  
  $fileName=$_FILES['file']['name'];
  $fileTmpName=$_FILES['file']['tmp_name'];
  $fileSize=$_FILES['file']['size'];
  $fileError=$_FILES['file']['error'];
  $fileType=$_FILES['file']['type'];
  $fileExt=explode('.',$fileName);
  $fileActualExt=strtolower(end($fileExt));
  $allowed=array('jpg','jpeg','png','docx','odt','pdf','ods');
  if(in_array($fileActualExt,$allowed))
 {
   if($fileError===0)
   {
	     if($fileSize<1000000)
	     {
	       $fileNameNew=uniqid('',true).".".$fileActualExt;
	       $fileDestination='uploads/'.$fileNameNew;
	       move_uploaded_file($fileTmpName, $fileDestination);
		header("Location:updatemarks.php?uploadsuccess");
	      }
	      else{
	       echo"Your file is too big!";}
	   
   }
 else
 {
  echo "there was an error uploading your file";
    }
  }
 else {
   echo "You cannot upload files of this type!"; }

}
?>
</body>
</html>

