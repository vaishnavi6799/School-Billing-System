<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>Student Page</title>

<link rel="stylesheet" href="css/style.css">
</head>
<body style="background:url(https://previews.123rf.com/images/tatus/tatus1407/tatus140700020/29843115-back-to-school-background.jpg); background-size:100%;">

  <center><h2 style="font-size:50px;color:Black;font-family:Heebo;">STUDENT INFORMATION</h2>
  
   <img src="imgs/s1.svg"width="300" height="300" class="avatar"/>
  </center>
  
  <form class="myform" action="student.php" method="post">
   <a href="FirstLanguage.php"><input type="button" id="ADD_btn" value="First_Language"/><br></a>
   <a href="Hindi.php"><input type="button" id="ADD_btn" value="Hindi"/><br></a>
   <a href="English.php"><input type="button" id="ADD_btn" value="English"/><br></a>
   <a href="Maths.php"><input type="button" id="ADD_btn" value="Maths"/><br></a>
   <a href="Science.php"><input type="button" id="ADD_btn" value="Science"/><br></a>
   <a href="Social.php"> <input type="button" id="ADD_btn" value="Social"/><br></a>
   <a href="GK.php"><input type="button" id="ADD_btn" value="GK"/><br></a>
   <a href="Sports.php"><input type="button" id="ADD_btn" value="Sports"/><br></a>
   <a href="Drawing.php"><input type="button" id="ADD_btn" value="Drawing"/><br></a>
   <a href="Computers.php"><input type="button" id="ADD_btn" value="Computers"/><br></a>
  
   <a href="fstudent.php"><input type="button" id="Back_btn" value="<<Back to homepage"/><br></a>
   <input name="logout" type="submit" id="Logout_btn" value="Log Out"/><br>
 
  </form>
   <?php
     if(isset($_POST['logout']))
     {
     session_destroy();
    header('location:findex.php');
     }
     
?>

</body>
</html>
