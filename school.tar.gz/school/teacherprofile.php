<?php
require'dbconfi/config.php';
$_GET['id'];
$_GET['fullname'];
$_GET['gender'];
$_GET['subject'];
$_GET['PersonalAddress'];
$_GET['EmailId'];
$_GET['MobileNo'];
?>
<!DOCTYPE html>
<html>
<head >
<title>Teacher profile</title>

<link rel="stylesheet" href="css/style.css">
</head>

<body style="background:url(https://previews.123rf.com/images/tatus/tatus1407/tatus140700020/29843115-back-to-school-background.jpg); background-size:100%;">

  <center><h2 style="font-size:50px;color:Black;font-family:Heebo;">TEACHER RECORD</h2>
   <img src="imgs/t1.svg" width="10" height="300" class="avatar"/>
  </center>
  
  <form class="myform" action="teacherprofile.php" method="post">
   <label><b>Full name:</b></label><br>
   <input name="fullname" type="text" class="inputvalues" readonly="readonly" value="<?php echo $_GET['fullname']?>" required/><br>
    <label><b>Gender:</b></label>
<input name="gender" type="text" class="inputvalues" readonly="readonly" value="<?php echo $_GET['gender']?>" required/><br>
     <label><b>subject:</b></label><br>
   <input name="subject" type="text" class="inputvalues" readonly="readonly" value="<?php echo $_GET['subject']?>" required/><br>
   <label><b>Personal Address:</b></label><br>
   <input name="PersonalAddress" type="text" class="inputvalues" readonly="readonly" value="<?php echo $_GET['PersonalAddress']?>" required/><br>
   <label><b>Email Id:</label><br>
   <input name="EmailId" type="text" class="inputvalues" readonly="readonly" value="<?php echo $_GET['EmailId']?>" required/><br>
   <label><b>Parent ph.No:</b></label><br>
   <input name="MobileNo" type="text" class="inputvalues" readonly="readonly" value="<?php echo $_GET['MobileNo']?>" required/><br> 
   <a href="updatemarks.php"><input type="button" id="SignUp_btn" value="Update Marks"/><br>
   <a href="fteacher.php"><input type="button" id="Back_btn" value="<<Back to teacher"/><br></a>
 
  </form>

</body>
</html>














